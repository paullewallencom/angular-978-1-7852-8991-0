angular.module('app.core').controller('ShowController', function(){
    var vm = this;

});
