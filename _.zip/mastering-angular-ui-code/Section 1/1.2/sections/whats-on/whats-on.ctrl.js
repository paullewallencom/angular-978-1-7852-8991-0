angular.module('app.core').controller('WhatsOnController', function(){
    var vm = this;

});
