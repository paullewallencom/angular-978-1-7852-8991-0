angular.module('app.core').controller('MyShowsController', function(){
    var vm = this;

});
