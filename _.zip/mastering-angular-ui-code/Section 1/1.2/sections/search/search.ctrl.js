angular.module('app.core').controller('SearchController', function(){
    var vm = this;

});
