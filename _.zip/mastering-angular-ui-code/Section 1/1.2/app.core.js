angular.module('app.core', []);
