angular.module('app.core', ['ui.bootstrap', 'ngAnimate']);
